/*
Navicat MySQL Data Transfer

Source Server         : localdatabase
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : books

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2021-03-13 20:07:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL,
  `name` char(20) DEFAULT NULL,
  `password` char(64) DEFAULT NULL,
  `email` char(255) DEFAULT NULL,
  `phone` char(20) DEFAULT NULL,
  `times` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '1',
  `lend_num` int(11) DEFAULT NULL,
  `max_num` int(11) DEFAULT NULL,
  PRIMARY KEY (`aid`,`username`) USING BTREE,
  KEY `username` (`username`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10011 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('10005', 'admin1', 'admin1', '1', '1068457627@qq.com', '13625694675', '0', '2', null, null);
INSERT INTO `admin` VALUES ('10007', '1', '1', '1', '2118457629@qq.com', '13625694682', '10', '1', '20', '3');
INSERT INTO `admin` VALUES ('10009', '2', '2', '2', '2123@qq.com', '12345678901', '0', '3', '45', '10');
INSERT INTO `admin` VALUES ('10010', 'admin2', 'admin2', '2', '5443@qq.com', '12345678901', '0', '2', null, null);

-- ----------------------------
-- Table structure for `book`
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(205) NOT NULL,
  `card` char(205) NOT NULL,
  `autho` char(205) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `press` char(205) DEFAULT NULL,
  `type` char(255) DEFAULT NULL,
  `times` int(11) DEFAULT '0',
  PRIMARY KEY (`bid`) USING BTREE,
  KEY `card` (`card`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2000007 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of book
-- ----------------------------

-- ----------------------------
-- Table structure for `booktype`
-- ----------------------------
DROP TABLE IF EXISTS `booktype`;
CREATE TABLE `booktype` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(50) NOT NULL,
  PRIMARY KEY (`tid`) USING BTREE,
  KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3005 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of booktype
-- ----------------------------

-- ----------------------------
-- Table structure for `history`
-- ----------------------------
DROP TABLE IF EXISTS `history`;
CREATE TABLE `history` (
  `hid` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) DEFAULT NULL,
  `bid` int(11) DEFAULT NULL,
  `card` int(11) DEFAULT NULL,
  `bookname` char(255) DEFAULT NULL,
  `adminname` char(255) DEFAULT NULL,
  `username` char(255) DEFAULT NULL,
  `begintime` char(255) DEFAULT NULL,
  `endtime` char(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`hid`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `bid` (`bid`) USING BTREE,
  KEY `bookname` (`bookname`) USING BTREE,
  KEY `adminname` (`adminname`) USING BTREE,
  KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=400020 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of history
-- ----------------------------

-- ----------------------------
-- Table structure for `problem`
-- ----------------------------
DROP TABLE IF EXISTS `problem`;
CREATE TABLE `problem` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) DEFAULT NULL,
  `name` char(50) DEFAULT NULL,
  `page` char(50) DEFAULT NULL,
  `body` char(255) DEFAULT NULL,
  `phone` char(20) DEFAULT NULL,
  `status` char(5) NOT NULL DEFAULT '未解决',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of problem
-- ----------------------------
